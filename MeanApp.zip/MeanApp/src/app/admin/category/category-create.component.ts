import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-create',
  templateUrl: './category-create.component.html',
  styles: []
})
export class CategoryCreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
