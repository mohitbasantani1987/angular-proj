import { Injectable } from "@angular/core";

@Injectable()
export class GlobalConfig {
    apibaseAddress = 'http://localhost:1300/api';
    cartName="myCart";
}
