export class Product {
    _id: string;
    name: string;
    unitPrice: number;
    imagePath: string;
    categoryId: string;
    createdDate: any;
    updatedDate: any;
    costructor() { }
}
