export class User {
    isAuth = false;
    userId: string;
    userName: string;
    password: string;
    fullName: string;
    address: string;
    role: string;
    roles = [];
    token: string;
    contactNo: string;
    createdDate: any;
    updatedDate: any;
    costructor() { }
}
